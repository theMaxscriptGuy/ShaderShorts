﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paint : MonoBehaviour
{
    [SerializeField]
    private Shader m_paintShader;
    private Material m_paintMat;
    private RaycastHit m_hit;
    private RenderTexture m_paintRT;
    private Material m_currentMaterial;
    void Start()
    {
        if(!m_paintShader)
        {
            enabled = false;
            return;
        }
        //this material is only for painting the paint map
        m_paintMat = new Material(m_paintShader);
        

        //get the current material with the existing Alpha map
        m_currentMaterial = GetComponent<Renderer>().sharedMaterial;
        Texture alphaTex = m_currentMaterial.GetTexture("_Alpha");

        m_paintRT = new RenderTexture(alphaTex.width, alphaTex.height, 0, RenderTextureFormat.ARGBFloat);
        //copy the alpha map of the current shader to the paint map so that it has the base map and doesnt start from single color
        Graphics.Blit(alphaTex, m_paintRT);
        //set the paint map to the currentMaterial/Shader
        m_currentMaterial.SetTexture("_Paint", m_paintRT);
    }

    void Update()
    {
        if(Input.GetKey(KeyCode.Mouse0))
        {
            if(Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out m_hit))
            {
                Debug.Log("HIT POINT");
                m_paintMat.SetVector("_HitCoordsUV", new Vector4(m_hit.textureCoord.x, m_hit.textureCoord.y, 0, 0));
                RenderTexture temp = RenderTexture.GetTemporary(m_paintRT.width, m_paintRT.height, 0, RenderTextureFormat.ARGBFloat);
                //copy paint map to temp:
                Graphics.Blit(m_paintRT, temp);
                //copy temp to paint map with currentMaterial with new paint added/removed
                Graphics.Blit(temp, m_paintRT, m_paintMat);
                RenderTexture.ReleaseTemporary(temp);
            }
        }
    }

    private void OnGUI()
    {
        GUI.DrawTexture(new Rect(0, 0, 128, 128), m_paintRT, ScaleMode.ScaleToFit, false);
    }
}
